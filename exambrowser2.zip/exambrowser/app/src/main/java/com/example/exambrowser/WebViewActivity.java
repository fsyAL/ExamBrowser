package com.example.exambrowser;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.text.format.DateFormat;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Calendar;

public class WebViewActivity extends AppCompatActivity {

    private WebView webView;
    private TextView timerTextView;
    private TextView batteryPercentageTextView;
    private TextView timeTextView;
    private CountDownTimer countDownTimer;
    private long timeLeftInMillis;
    private LockTaskManager lockTaskManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_webview);

        // Set the FLAG_SECURE to prevent screenshots and screen recording
        getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE,
                android.view.WindowManager.LayoutParams.FLAG_SECURE);

        hideSystemUI();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        webView = findViewById(R.id.webView);
        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);

        lockTaskManager = new LockTaskManager(this);

        String url = getIntent().getStringExtra("url");
        int durasi = getIntent().getIntExtra("durasi", 0);
        timeLeftInMillis = durasi * 60000;

        if (url != null && !url.isEmpty()) {
            webView.loadUrl(url);
        }

        timerTextView = findViewById(R.id.timerTextView);
        batteryPercentageTextView = findViewById(R.id.batteryPercentageTextView);
        timeTextView = findViewById(R.id.timeTextView);
        startCountDown();

        registerBatteryReceiver();
        updateTime();
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    private void registerBatteryReceiver() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        registerReceiver(batteryReceiver, filter);
    }

    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
            if (level >= 0 && scale > 0) {
                int batteryPercentage = (int) ((level / (float) scale) * 100);
                batteryPercentageTextView.setText(batteryPercentage + "%");
            }
        }
    };

    private void startCountDown() {
        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                updateTimer();
            }

            @Override
            public void onFinish() {
                stopLockTask();
                finish();
            }
        }.start();
    }

    private void updateTimer() {
        int minutes = (int) (timeLeftInMillis / 1000) / 60;
        int seconds = (int) (timeLeftInMillis / 1000) % 60;

        String timeLeftFormatted = String.format("%02d:%02d", minutes, seconds);
        timerTextView.setText(timeLeftFormatted);
    }

    private void updateTime() {
        final Calendar calendar = Calendar.getInstance();
        String currentTime = DateFormat.format("HH:mm:ss", calendar).toString();
        timeTextView.setText(currentTime);

        timeTextView.postDelayed(new Runnable() {
            @Override
            public void run() {
                updateTime();
            }
        }, 1000);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!lockTaskManager.isInLockTaskMode()) {
            if (!lockTaskManager.getKeyguardManager().isKeyguardLocked()) {
                lockTaskManager.showLockTaskDialog(() -> {});
            } else {
                lockTaskManager.showLockTaskDialog(() -> {});
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        webView.loadUrl("about:blank");
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
        unregisterReceiver(batteryReceiver);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_webview, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_refresh) {
            webView.reload();
            return true;
        } else if (id == R.id.action_undo) {
            if (webView.canGoBack()) {
                webView.goBack();
            }
            return true;
        } else if (id == R.id.action_exit) {
            stopLockTask();
            Intent intent = new Intent(WebViewActivity.this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        // Disable back button functionality
    }
}
