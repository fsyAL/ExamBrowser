package com.example.exambrowser;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MapelActivity extends AppCompatActivity {

    private ListView listView;
    private OkHttpClient client;
    private List<String> mapelList;
    private List<String> linkList;
    private List<Integer> durasiList;
    private LockTaskManager lockTaskManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapel);

        listView = findViewById(R.id.listView);
        client = new OkHttpClient();
        mapelList = new ArrayList<>();
        linkList = new ArrayList<>();
        durasiList = new ArrayList<>();
        lockTaskManager = new LockTaskManager(this);

        fetchDataFromCSV();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!lockTaskManager.isInLockTaskMode()) {
            showExitDialog();
        }
    }

    private void showExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_exit, null);
        builder.setView(dialogView);

        TextView dialogTitle = dialogView.findViewById(R.id.dialog_title);
        TextView dialogMessage = dialogView.findViewById(R.id.dialog_message);
        Button buttonExit = dialogView.findViewById(R.id.button_exit);

        dialogTitle.setText("Lock Task Required");
        dialogMessage.setText("You must activate Lock Task mode to continue.");

        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();
    }

    private void fetchDataFromCSV() {
        String url = "https://spreadsheet.google.com/tq?tqx=out:csv&key=1VzKQZVJZIb5Bqv0WlH8vk8mm6XbSAuTsG5QzUqDpFlc";

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(MapelActivity.this, "Failed to connect to server", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    parseCSVData(responseData);
                } else {
                    runOnUiThread(() -> Toast.makeText(MapelActivity.this, "Error: " + response.message(), Toast.LENGTH_SHORT).show());
                }
            }
        });
    }

    private void parseCSVData(String csvData) {
        String[] lines = csvData.split("\n");
        for (int i = 1; i < lines.length; i++) {
            String line = lines[i].trim();
            String[] columns = line.split(",");

            if (columns.length > 6) {
                String mapel = columns[0].replace("\"", "").trim();
                String kelas = columns[1].replace("\"", "").trim();
                String sesi = columns[2].replace("\"", "").trim();
                String token = columns[3].replace("\"", "").trim();
                String durasi = columns[4].replace("\"", "").trim();
                String linkSoal = columns[6].replace("\"", "").trim();

                String displayText = "MAPEL: " + mapel + "\nKELAS: " + kelas + "\nSESI: " + sesi + "\nTOKEN: " + token;
                mapelList.add(displayText);
                linkList.add(linkSoal);

                if (!durasi.isEmpty()) {
                    durasiList.add(Integer.parseInt(durasi));
                } else {
                    durasiList.add(0);
                }
            }
        }

        runOnUiThread(() -> {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(MapelActivity.this, R.layout.list_item_mapel, R.id.mapel_name, mapelList);
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String link = linkList.get(position);
                    int durasi = durasiList.get(position);
                    Intent intent = new Intent(MapelActivity.this, WebViewActivity.class);
                    intent.putExtra("url", link);
                    intent.putExtra("durasi", durasi);
                    startActivity(intent);
                }
            });
        });
    }
}
