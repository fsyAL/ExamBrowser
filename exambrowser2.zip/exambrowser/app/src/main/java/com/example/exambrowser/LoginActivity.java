package com.example.exambrowser;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import android.view.LayoutInflater;
import android.app.Dialog;
import java.io.IOException;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

public class LoginActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_OVERLAY_PERMISSION = 100;
    private EditText editTextToken;
    private Button buttonLogin;
    private OkHttpClient client;
    private LockTaskManager lockTaskManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextToken = findViewById(R.id.editTextToken);
        buttonLogin = findViewById(R.id.buttonLogin);
        client = new OkHttpClient();
        lockTaskManager = new LockTaskManager(this);

        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQUEST_CODE_OVERLAY_PERMISSION);
        } else {
            checkLockTask();
        }

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String token = editTextToken.getText().toString().trim();
                if (!token.isEmpty()) {
                    checkToken(token);
                } else {
                    editTextToken.setError("Token cannot be empty");
                }
            }
        });

        TextView infoSymbol = findViewById(R.id.infoSymbol);
        infoSymbol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showCreditsDialog();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_OVERLAY_PERMISSION) {
            if (Settings.canDrawOverlays(this)) {
                checkLockTask();
            } else {
                Toast.makeText(this, "Overlay permission is required to proceed.", Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    private void checkLockTask() {
        if (!lockTaskManager.isInLockTaskMode()) {
            lockTaskManager.showLockTaskDialog(() -> {
                String token = editTextToken.getText().toString().trim();
                if (!token.isEmpty()) {
                    checkToken(token);
                } else {
                    editTextToken.setError("Token cannot be empty");
                }
            });
        }
    }

    private void checkToken(String token) {
        String url = "https://spreadsheet.google.com/tq?tqx=out:csv&key=1VzKQZVJZIb5Bqv0WlH8vk8mm6XbSAuTsG5QzUqDpFlc";

        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                runOnUiThread(() -> Toast.makeText(LoginActivity.this, "Failed to connect to server", Toast.LENGTH_SHORT).show());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful()) {
                    String responseData = response.body().string();
                    boolean isValid = isTokenValid(responseData, token);
                    if (isValid) {
                        runOnUiThread(() -> {
                            Toast.makeText(LoginActivity.this, "Token benar", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, MapelActivity.class);
                            startActivity(intent);
                            finish();
                        });
                    }
                } else {
                    runOnUiThread(() -> Toast.makeText(LoginActivity.this, "Error: " + response.message(), Toast.LENGTH_SHORT).show());
                }
            }
        });
    }

    private boolean isTokenValid(String csvData, String token) {
        String[] lines = csvData.split("\n");
        for (int i = 1; i < lines.length; i++) {
            String line = lines[i].trim();
            String[] columns = line.split(",");
            if (columns.length > 3) {
                String csvToken = columns[3].replace("\"", "").trim();
                if (csvToken.equalsIgnoreCase(token)) {
                    return true;
                }
            }
        }
        return false;
    }

    private void showCreditsDialog() {
        LayoutInflater inflater = getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_credits, null);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setView(dialogView);

        AlertDialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        Button buttonOk = dialogView.findViewById(R.id.buttonOk);
        buttonOk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }
}
