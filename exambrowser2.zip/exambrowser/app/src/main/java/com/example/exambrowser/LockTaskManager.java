package com.example.exambrowser;

import android.app.ActivityManager;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;

public class LockTaskManager {
    private Context context;
    private KeyguardManager keyguardManager;

    public LockTaskManager(Context context) {
        this.context = context;
        this.keyguardManager = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
    }

    public boolean isInLockTaskMode() {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        return activityManager != null && activityManager.getLockTaskModeState() != ActivityManager.LOCK_TASK_MODE_NONE;
    }

    public void showLockTaskDialog(final Runnable onActivate) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.custom_dialog, null);

        AlertDialog dialog = new AlertDialog.Builder(context)
            .setView(dialogView)
            .setCancelable(false)
            .create();

        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        Button activateButton = dialogView.findViewById(R.id.button_activate);
        activateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startLockTask();
                onActivate.run();
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    private void startLockTask() {
        if (context instanceof WebViewActivity) {
            ((WebViewActivity) context).startLockTask();
        } else if (context instanceof LoginActivity) {
            ((LoginActivity) context).startLockTask();
        }
    }

    public KeyguardManager getKeyguardManager() {
        return keyguardManager;
    }
}